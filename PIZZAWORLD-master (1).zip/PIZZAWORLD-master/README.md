PIZZAROLD

PIZZAWORLD necesita una aplicación que ofrezca la siguiente funcionalidad:

1-Mostrar todas las pizzas disponibles.
2-Ver la información de una pizza en concreto.
3-Añadir comentarios a una pizza.
4-Crear una pizza introduciendo su nombre, los ingredientes y una imagen.

Los usuarios deben poder registrarse en la aplicación por medio de un formulario de registro y obtener una credencial de login con el user y password deseado.

Se requiere diseñar las siguientes Entidades:
Pizza:
  nombre, foto, ingredientes, comentarios y precio. 
     El precio se calcula de la siguiente forma:
         Precio = SUM(Precio_Ingrediente) + 5€
Ingrediente: 
   nombre y precio.
Comentario: texto, puntuación, fecha, usuario y pizza.
Usuario: email, nombre, apellidos y contraseña.
Todos los campos son requeridos excepto los ingredientes de una pizza y sus comentarios.

EJERCICIO:
 1- Configurar un equipo SCRUM.
 2- Describir el BACKLOG de PRODUCTO.
 3- Diseñar los Escenarios de uso de la aplicación:
 4- Preparar el primer SPRINT.
 5- Mockear los componentes gráficos.
 
Vistas:
En el espacio restante de la ventana han de aparecer los siguientes elementos en función de la ruta:
/pizzas : una card por cada pizza que contenga su imagen y nombre, al  pulsar en dicha card se ha de mostrar la información de la pizza seleccionada.
/pizzas/:id : muestra la información de una pizza en concreto, aparecen su imagen y nombre y a la derecha una lista con sus ingredientes (nombre y precio). Debajo aparece el formulario para añadir un comentario con los campos puntuación (entre 0 y 10) y texto. Debajo de este formulario aparecen todos los comentarios de la pizza mostrando el usuario, la fecha, la puntuación y el texto.
/pizzas/add : formulario para añadir una pizza. Requiere nombre, ingredientes (a seleccionar de los ingredientes existentes) y una imagen de la pizza. La imagen seleccionada debe poder visualizarse.

