 package es.once.Pizza.model;

import java.util.List;



import org.springframework.data.jpa.repository.JpaRepository;

public interface PizzaRepository extends JpaRepository<Pizza, Long>{

     List<Pizza> findByNombre(String nombre);
    
}