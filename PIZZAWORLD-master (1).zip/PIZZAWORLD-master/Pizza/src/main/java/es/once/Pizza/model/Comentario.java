package es.once.Pizza.model;

public class Comentario {

}
