package es.once.Pizza.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *  class pizza
 */
@Entity
public class Pizza {
    @Id 
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    @NotNull
    @Size(min=5, max=25)
    private String nombre;
    @NotNull
    private String imageReference;      //almacena una referencia a una imagen
                                        //ya se verá donde se alamacenan
    private  List<Ingrediente> ingredientes;
    private List<Comentario> comentarios;

    //cálculo del precio Precio= suma precio ingredientes más 5
    public double precio(){
        double precio=0.0;
        for (Ingrediente i : ingredientes) {
            precio += i.getPrecio();
        }
        return precio +5;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getImageReference() {
        return imageReference;
    }

    public void setImageReference(String imageReference) {
        this.imageReference = imageReference;
    }

    public List<Ingrediente> getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(List<Ingrediente> ingredientes) {
        this.ingredientes = ingredientes;
    }

    public List<Comentario> getComentarios() {
        return comentarios;
    }

    public void setComentarios(List<Comentario> comentarios) {
        this.comentarios = comentarios;
    }

    public Pizza(   String nombre,
                    String imageReference, 
                    List<Ingrediente> ingredientes, 
                    List<Comentario> comentarios
    ) {
        this.nombre = nombre;
        this.imageReference = imageReference;
        this.ingredientes = ingredientes;
        this.comentarios = comentarios;
    }




}